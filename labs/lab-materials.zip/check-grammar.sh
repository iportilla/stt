#!/bin/bash
curl -X GET -u apikey:$APIKEY "$URL/v1/customizations/$AUTO_LM/grammars/claimnumber"
